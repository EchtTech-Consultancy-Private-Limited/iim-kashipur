<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class categorycontroller extends Controller
{
    //
}
