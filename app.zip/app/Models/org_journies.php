<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class org_journies extends Model
{
    use HasFactory;
    protected $table ='org_journey';
}
